# Autotask → aBILLity Company Name Sync

Keeps a Company's name in sync from Autotask to aBILLity, triggered by an Autotask webhook, via an Azure Function.

## Contents

- **`autotask-abillity-sync.ps1`** — one-time setup script. Resolves your Autotask zone, creates the webhook, and registers `CompanyName` plus your aBILLity-ID UDF as trigger/display fields. Run this once, after the Function App below is deployed and you have its live URLs.
- **`AutotaskAbillitySync/`** — the Azure Functions project (PowerShell, Consumption plan):
  - `CompanyNameSync/` — the webhook receiver. Reads the Autotask payload, pulls the new name + linked aBILLity ID, PATCHes aBILLity.
  - `CompanyNameSyncDeactivated/` — the callback Autotask requires for when the webhook is deactivated.
  - `host.json` — standard Functions host config.
  - `local.settings.json.example` — template for local secrets. Copy to `local.settings.json` and fill in real values; that file is gitignored and never committed.

## Setup

Full walkthrough with CLI/Portal steps, deployment, and a test checklist: see the companion doc `azure-function-test-setup.md` (not part of this repo — kept alongside it if you want the narrative version).

Quick path:
1. Deploy `AutotaskAbillitySync/` to an Azure Function App (PowerShell runtime, Consumption plan).
2. Set the four app settings in Azure (`AutotaskUdfLabel`, `AbillitySystemInformation`, `AbillityUserName`, `AbillityPassword`) — mirror `local.settings.json.example`.
3. Grab both function URLs (with their `?code=` keys) from the Portal.
4. Fill those into `$WebhookUrl` / `$DeactivationUrl` at the top of `autotask-abillity-sync.ps1`, along with your Autotask API credentials and UDF label.
5. Run `autotask-abillity-sync.ps1` once to register the webhook.

## Security notes

- Never commit `local.settings.json` — only `local.settings.json.example` should be in the repo.
- The Function-level `?code=` key on each URL is the practical authenticity check here, since Autotask's own `SecretKey` mechanism isn't documented with a specific header/signature scheme.
- aBILLity's `Name` field caps at 50 characters — the receiver truncates rather than failing on longer Autotask names.
